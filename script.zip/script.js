/* ═══════════════════════════════════════
   SAIRA JANE SAYSON — PORTFOLIO SCRIPT
   Storage: IndexedDB (no size limit)
═══════════════════════════════════════ */

// ── ADMIN SHORTCUT ──
document.addEventListener("keydown", e => {
  if (e.ctrlKey && e.shiftKey && (e.key === "A" || e.key === "a" || e.code === "KeyA")) {
    e.preventDefault();
    if (typeof goAdmin === "function") goAdmin();
  }
});

// ── STATIC GALLERY — auto lightbox, reads directly from the HTML ──
function initGalleryLightbox() {
  const cells = document.querySelectorAll("#galleryGrid .gallery-cell");
  const photos = Array.from(cells).map(cell => {
    const img = cell.querySelector("img");
    return { dataUrl: img ? img.src : "", name: img ? img.alt : "" };
  });
  cells.forEach((cell, idx) => {
    cell.style.cursor = "pointer";
    cell.onclick = () => openLightbox(photos, idx);
  });
}

// ── EmailJS ──
emailjs.init("SK9le-xyx9yAtBZ7O");
function sendEmail(e) {
  e.preventDefault();
  const btn = document.getElementById("sendBtn");
  const feedback = document.getElementById("formFeedback");
  btn.disabled = true; btn.classList.add("loading");
  feedback.className = "form-feedback"; feedback.textContent = "";
  const params = {
    from_name:  document.getElementById("fromName").value.trim(),
    from_email: document.getElementById("fromEmail").value.trim(),
    message:    document.getElementById("message").value.trim(),
    to_email:   "sairajanesayson@gmail.com"
  };
  emailjs.send("service_4ifljvc", "template_1ll3s59", params)
    .then(() => {
      btn.disabled = false; btn.classList.remove("loading");
      feedback.textContent = "✓ Message sent! I'll get back to you soon.";
      feedback.className = "form-feedback success show";
      document.getElementById("contactForm").reset();
    })
    .catch(err => {
      btn.disabled = false; btn.classList.remove("loading");
      feedback.textContent = "✗ Something went wrong. Please try again.";
      feedback.className = "form-feedback error show";
      console.error(err);
    });
}

/* ══════════════════════════════════════
   INDEXEDDB — no size limit, works on
   GitHub Pages and local files both
══════════════════════════════════════ */
const DB_NAME    = "sairaPortfolio";
const DB_VERSION = 1;
let db = null;

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = function(e) {
      const d = e.target.result;
      if (!d.objectStoreNames.contains("projects"))   d.createObjectStore("projects",   { keyPath: "id" });
      if (!d.objectStoreNames.contains("gallery"))    d.createObjectStore("gallery",    { keyPath: "id" });
      if (!d.objectStoreNames.contains("unfinished")) d.createObjectStore("unfinished", { keyPath: "id" });
      if (!d.objectStoreNames.contains("skills"))     d.createObjectStore("skills",     { keyPath: "id" });
      if (!d.objectStoreNames.contains("meta"))       d.createObjectStore("meta");
    };
    req.onsuccess  = e => resolve(e.target.result);
    req.onerror    = e => reject(e.target.error);
  });
}

function dbGet(store, key) {
  return new Promise((resolve, reject) => {
    const tx  = db.transaction(store, "readonly");
    const req = tx.objectStore(store).get(key);
    req.onsuccess = e => resolve(e.target.result);
    req.onerror   = e => reject(e.target.error);
  });
}

function dbGetAll(store) {
  return new Promise((resolve, reject) => {
    const tx  = db.transaction(store, "readonly");
    const req = tx.objectStore(store).getAll();
    req.onsuccess = e => resolve(e.target.result);
    req.onerror   = e => reject(e.target.error);
  });
}

function dbPut(store, value, key) {
  return new Promise((resolve, reject) => {
    const tx  = db.transaction(store, "readwrite");
    const req = key !== undefined
      ? tx.objectStore(store).put(value, key)
      : tx.objectStore(store).put(value);
    req.onsuccess = e => resolve(e.target.result);
    req.onerror   = e => reject(e.target.error);
  });
}

function dbDelete(store, key) {
  return new Promise((resolve, reject) => {
    const tx  = db.transaction(store, "readwrite");
    const req = tx.objectStore(store).delete(key);
    req.onsuccess = () => resolve();
    req.onerror   = e  => reject(e.target.error);
  });
}

/* ══════════════════════
   DATA (loaded from DB)
══════════════════════ */
const DATA = { projects: [], gallery: [], unfinished: [], skills: [] };
let nextId = 100;

const DEFAULT_UNFINISHED = [{ id: 1, title: "Title", category: "Coming Soon", desc: "Placeholder for description", progress: 40 }];
const DEFAULT_SKILLS     = [
  { id: 1, name: "Hardware", percent: 15 },
  { id: 2, name: "Wiring",   percent: 20 },
  { id: 3, name: "Coding",   percent: 25 },
  { id: 4, name: "Sleep",    percent: 10 }
];

async function initDB() {
  db = await openDB();

  // Load all sections in parallel
  const [projects, gallery, unfinished, skills, storedId] = await Promise.all([
    dbGetAll("projects"),
    dbGetAll("gallery"),
    dbGetAll("unfinished"),
    dbGetAll("skills"),
    dbGet("meta", "nextId")
  ]);

  DATA.projects   = projects   || [];
  DATA.gallery    = gallery    || [];
  DATA.unfinished = unfinished && unfinished.length ? unfinished : DEFAULT_UNFINISHED;
  DATA.skills     = skills     && skills.length     ? skills     : DEFAULT_SKILLS;
  nextId          = storedId   || 100;

  // Seed defaults if empty
  if (!unfinished || !unfinished.length) {
    for (const u of DEFAULT_UNFINISHED) await dbPut("unfinished", u);
  }
  if (!skills || !skills.length) {
    for (const s of DEFAULT_SKILLS) await dbPut("skills", s);
  }

  // Projects and gallery are hardcoded in HTML — don't overwrite them
  // Only render dynamic sections
  initGalleryLightbox();
  renderUnfinished();
  renderSkills();
  type();
}

async function saveNextId() {
  await dbPut("meta", nextId, "nextId");
}

/* ══════════════════════
   TYPED ANIMATION
══════════════════════ */
const phrases = [
  "Computer Engineering Student, University of Bohol.",
  "Passionate about hardware & software.",
  "Building the future, one circuit at a time."
];
let tI = 0, tJ = 0, tDel = false;
const typedEl = document.getElementById("typed");
function type() {
  if (!typedEl) return;
  typedEl.textContent = phrases[tI].slice(0, tJ += (tDel ? -1 : 1));
  if (!tDel && tJ === phrases[tI].length) { tDel = true; setTimeout(type, 1400); return; }
  if (tDel && tJ === 0) { tDel = false; tI = (tI + 1) % phrases.length; setTimeout(type, 500); return; }
  setTimeout(type, tDel ? 40 : 80);
}

/* ══════════════════════
   TOAST
══════════════════════ */
function showToast(msg, type) {
  const t = document.getElementById("toast");
  if (!t) return;
  t.textContent = msg;
  t.className = "toast " + type + " show";
  setTimeout(() => t.classList.remove("show"), 3500);
}

/* ══════════════════════
   NAVIGATION
══════════════════════ */
function showSection(id) {
  document.querySelectorAll("section").forEach(s => s.classList.remove("active"));
  document.querySelectorAll(".nav-links a[data-section]").forEach(a => a.classList.remove("active"));
  const sec = document.getElementById(id);
  if (sec) sec.classList.add("active");
  const lnk = document.querySelector('.nav-links a[data-section="' + id + '"]');
  if (lnk) lnk.classList.add("active");
  if (id === "unfinished") renderUnfinished();
}
function nav(e, id)   { e.preventDefault(); showSection(id); closeDD(); }
function navDD(e, id) { e.preventDefault(); showSection(id); closeDD(); }
function toggleDD()   { document.getElementById("projectsDD").classList.toggle("open"); }
function closeDD()    { document.getElementById("projectsDD").classList.remove("open"); }
document.addEventListener("click", e => {
  const dd = document.getElementById("projectsDD");
  if (dd && !dd.contains(e.target)) closeDD();
});

/* ══════════════════════
   ADMIN
══════════════════════ */
const ADMIN_PW = "sayson2501-1340";
let adminUnlocked = false;

function goAdmin() {
  if (adminUnlocked) {
    showSection("admin");
    renderAdminProjects(); renderAdminUnfinished(); renderAdminGallery(); renderAdminSkills();
    return;
  }
  document.getElementById("adminLock").style.display = "flex";
  document.getElementById("adminPwInput").value = "";
  setTimeout(() => document.getElementById("adminPwInput").focus(), 100);
}
function cancelAdmin() { document.getElementById("adminLock").style.display = "none"; }
function checkAdminPw() {
  const pw = document.getElementById("adminPwInput").value;
  if (pw === ADMIN_PW) {
    adminUnlocked = true;
    document.getElementById("adminLock").style.display = "none";
    document.getElementById("adminNavBtn").classList.add("visible");
    showSection("admin");
    renderAdminProjects(); renderAdminUnfinished(); renderAdminGallery(); renderAdminSkills();
    showToast("Admin panel unlocked!", "success");
  } else {
    showToast("Wrong password.", "error");
    document.getElementById("adminPwInput").value = "";
    document.getElementById("adminPwInput").focus();
  }
}
const adminPwInput = document.getElementById("adminPwInput");
if (adminPwInput) adminPwInput.addEventListener("keydown", e => { if (e.key === "Enter") checkAdminPw(); });

function switchAdminTab(tab, e) {
  document.querySelectorAll(".admin-tab").forEach(t => t.classList.remove("active"));
  document.querySelectorAll(".admin-pane").forEach(p => p.classList.remove("active"));
  if (e && e.target) e.target.classList.add("active");
  document.getElementById("adminPane-" + tab).classList.add("active");
}

/* ══════════════════════
   PROJECTS
══════════════════════ */
const dropZone = document.getElementById("dropZone");
if (dropZone) {
  dropZone.addEventListener("dragover",  e => { e.preventDefault(); dropZone.classList.add("drag-over"); });
  dropZone.addEventListener("dragleave", () => dropZone.classList.remove("drag-over"));
  dropZone.addEventListener("drop", e => { e.preventDefault(); dropZone.classList.remove("drag-over"); handleProjectFileDrop(e.dataTransfer.files); });
}

let pendingProjectFiles = [];
let pendingProjectImg   = null;

function handleProjectFilePick(files) { if (files && files.length) handleProjectFileDrop(files); }

function handleProjectFileDrop(fileList) {
  if (!fileList || !fileList.length) return;
  const incoming = Array.from(fileList);
  if (pendingProjectFiles.length + incoming.length > 10) { showToast("Maximum 10 files allowed.", "error"); return; }
  const wasEmpty = pendingProjectFiles.length === 0;
  incoming.forEach(file => {
    const reader = new FileReader();
    reader.onload = function(ev) {
      // Store as plain object — name, dataUrl, size only (no File object)
      pendingProjectFiles.push({ name: file.name, dataUrl: ev.target.result, size: file.size });
      renderFileChips();
    };
    reader.readAsDataURL(file);
  });
  document.getElementById("dropZone").style.display = "none";
  document.getElementById("projectFormPanel").style.display = "block";
  if (wasEmpty) {
    document.getElementById("pfTitle").value = capitalize(incoming[0].name.replace(/\.[^.]+$/, "").replace(/[-_]/g, " "));
    document.getElementById("pfImgPreview").style.display = "none";
    document.getElementById("pfImgLabel").textContent = "📷 Choose Image";
    document.getElementById("pfLink").value  = "";
    document.getElementById("pfDesc").value  = "";
  }
}

function renderFileChips() {
  const row = document.getElementById("pfFileRow");
  if (!row) return;
  row.innerHTML = "";
  pendingProjectFiles.forEach((pf, idx) => {
    const chip = document.createElement("div");
    chip.className = "pf-file-chip";
    chip.innerHTML =
      '<span class="pf-file-icon">📄</span>' +
      '<span class="pf-chip-name">' + pf.name + '</span>' +
      '<span class="pf-chip-meta">' + pf.name.split(".").pop().toUpperCase() + ' · ' + formatBytes(pf.size) + '</span>' +
      '<button class="pf-chip-remove" onclick="removeProjectFile(' + idx + ')" title="Remove">✕</button>';
    row.appendChild(chip);
  });
  if (pendingProjectFiles.length < 10) {
    const addBtn = document.createElement("div");
    addBtn.className = "pf-add-more";
    addBtn.innerHTML = "<span>+ Add more files</span>";
    addBtn.onclick = () => {
      const inp = document.createElement("input");
      inp.type = "file"; inp.multiple = true; inp.style.display = "none";
      inp.onchange = () => handleProjectFileDrop(inp.files);
      document.body.appendChild(inp); inp.click();
      setTimeout(() => inp.remove(), 5000);
    };
    row.appendChild(addBtn);
  }
}

function removeProjectFile(idx) {
  pendingProjectFiles.splice(idx, 1);
  if (!pendingProjectFiles.length) cancelProjectForm(); else renderFileChips();
}

function handleProjectImg(input) {
  if (!input.files[0]) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    pendingProjectImg = e.target.result;
    const preview = document.getElementById("pfImgPreview");
    preview.src = pendingProjectImg; preview.style.display = "block";
    document.getElementById("pfImgLabel").textContent = "✓ " + input.files[0].name;
  };
  reader.readAsDataURL(input.files[0]);
}

async function submitProject() {
  const title = document.getElementById("pfTitle").value.trim();
  if (!title) { showToast("Please enter a project title.", "error"); return; }
  const desc = document.getElementById("pfDesc").value.trim();
  if (!desc)  { showToast("Please add a description.", "error"); return; }

  const project = {
    id:       ++nextId,
    title,
    category: document.getElementById("pfCategory").value.trim() || "Project",
    desc,
    link:     document.getElementById("pfLink").value.trim(),
    imgData:  pendingProjectImg || null,
    files:    pendingProjectFiles.map(pf => ({ name: pf.name, dataUrl: pf.dataUrl, size: pf.size }))
  };

  await dbPut("projects", project);
  await saveNextId();
  DATA.projects.push(project);

  cancelProjectForm();
  renderProjects();
  renderAdminProjects();
  showToast("Project saved! ✓", "success");
}

function cancelProjectForm() {
  pendingProjectFiles = []; pendingProjectImg = null;
  document.getElementById("dropZone").style.display = "";
  document.getElementById("projectFormPanel").style.display = "none";
  document.getElementById("projectFileInput").value = "";
  document.getElementById("pfImgInput").value = "";
  document.getElementById("pfFileRow").innerHTML = "";
  ["pfTitle","pfCategory","pfDesc","pfLink"].forEach(id => document.getElementById(id).value = "");
  document.getElementById("pfImgPreview").style.display = "none";
  document.getElementById("pfImgLabel").textContent = "📷 Choose Image";
}

function fileIcon(name) {
  const ext = name.split(".").pop().toLowerCase();
  if (ext === "html") return "🌐";
  if (ext === "css")  return "🎨";
  if (ext === "js")   return "⚡";
  if (ext === "pdf")  return "📕";
  if (["jpg","jpeg","png","gif","svg","webp"].includes(ext)) return "🖼";
  if (["zip","rar","7z"].includes(ext)) return "🗜";
  return "📄";
}

function renderProjects() {
  const grid = document.getElementById("projectsGrid");
  if (!grid) return;
  grid.innerHTML = "";
  if (!DATA.projects.length) {
    grid.innerHTML = '<p style="color:var(--muted);font-size:14px;">No projects yet — add one from the admin panel.</p>';
    return;
  }
  DATA.projects.forEach(p => {
    const files = p.files || [];
    const fileListHTML = files.length
      ? '<div class="project-files-list">' + files.map(f =>
          '<a class="project-file-item" href="' + f.dataUrl + '" download="' + f.name + '">' +
            '<span class="pfi-icon">' + fileIcon(f.name) + '</span>' +
            '<span class="pfi-name">' + f.name + '</span>' +
            '<span class="pfi-size">' + formatBytes(f.size) + '</span>' +
            '<span class="pfi-dl">↓</span></a>').join("") + '</div>'
      : "";
    const card = document.createElement("div");
    card.className = "project-card";
    card.innerHTML =
      (p.imgData ? '<img class="project-card-img" src="' + p.imgData + '" alt="' + p.title + '"/>'
                 : '<div class="project-card-img-placeholder">🗂</div>') +
      '<div class="project-card-body">' +
        '<div class="project-meta">' + p.category + '</div>' +
        '<h3>' + p.title + '</h3><p>' + p.desc + '</p>' + fileListHTML +
        '<div class="project-card-footer">' +
          (p.link ? '<a class="btn-sm" href="' + p.link + '" target="_blank">View Live →</a>' : "") +
          (adminUnlocked ? '<button class="btn-sm danger" onclick="deleteProject(' + p.id + ')">Delete</button>' : "") +
        '</div></div>';
    grid.appendChild(card);
  });
}

function renderAdminProjects() {
  const list = document.getElementById("adminProjectsList");
  if (!list) return;
  list.innerHTML = "";
  if (!DATA.projects.length) { list.innerHTML = '<p style="color:var(--muted);font-size:13px;">No projects yet.</p>'; return; }
  DATA.projects.forEach(p => {
    const files = p.files || [];
    const div = document.createElement("div");
    div.className = "admin-list-item";
    div.innerHTML =
      (p.imgData ? '<img class="preview-thumb" src="' + p.imgData + '" alt=""/>'
                 : '<div style="width:60px;height:40px;border-radius:4px;background:var(--surface2);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;">🗂</div>') +
      '<div class="item-info"><div class="item-title">' + p.title + '</div>' +
      '<div class="item-sub">' + p.category + (files.length ? " · " + files.length + " file(s)" : "") + '</div></div>' +
      '<div class="item-actions"><button class="admin-btn danger" onclick="deleteProject(' + p.id + ')">Delete</button></div>';
    list.appendChild(div);
  });
}

async function deleteProject(id) {
  await dbDelete("projects", id);
  DATA.projects = DATA.projects.filter(p => p.id !== id);
  renderProjects(); renderAdminProjects();
  showToast("Project removed.", "error");
}

/* ══════════════════════
   GALLERY
══════════════════════ */
let pendingGalleryFiles = [];

function handleFileSelect(event) {
  const files = Array.from(event.target.files);
  if (!files.length) return;
  pendingGalleryFiles = [];
  document.getElementById("imgPreviewStrip").innerHTML = "";
  document.getElementById("uploadChosen").textContent = "Reading " + files.length + " photo(s)...";
  let done = 0;
  files.forEach(file => {
    const reader = new FileReader();
    reader.onload = function(e) {
      pendingGalleryFiles.push({ name: file.name, dataUrl: e.target.result });
      const img = document.createElement("img");
      img.src = e.target.result;
      document.getElementById("imgPreviewStrip").appendChild(img);
      done++;
      document.getElementById("uploadChosen").textContent = done + " of " + files.length + " photo(s) ready";
    };
    reader.readAsDataURL(file);
  });
}

const galleryDropArea = document.getElementById("galleryDropArea");
if (galleryDropArea) {
  galleryDropArea.addEventListener("dragover",  e => { e.preventDefault(); galleryDropArea.style.borderColor = "var(--accent)"; });
  galleryDropArea.addEventListener("dragleave", () => { galleryDropArea.style.borderColor = ""; });
  galleryDropArea.addEventListener("drop", e => {
    e.preventDefault(); galleryDropArea.style.borderColor = "";
    const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith("image/"));
    if (!files.length) return;
    pendingGalleryFiles = [];
    document.getElementById("imgPreviewStrip").innerHTML = "";
    document.getElementById("uploadChosen").textContent = "Reading " + files.length + " photo(s)...";
    let done = 0;
    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = function(ev) {
        pendingGalleryFiles.push({ name: file.name, dataUrl: ev.target.result });
        const img = document.createElement("img");
        img.src = ev.target.result;
        document.getElementById("imgPreviewStrip").appendChild(img);
        done++;
        document.getElementById("uploadChosen").textContent = done + " of " + files.length + " photo(s) ready";
      };
      reader.readAsDataURL(file);
    });
  });
}

async function addGalleryPhotos() {
  if (!pendingGalleryFiles.length) { showToast("Please select at least one photo.", "error"); return; }
  showToast("Saving " + pendingGalleryFiles.length + " photo(s)...", "success");
  for (const f of pendingGalleryFiles) {
    const photo = { id: ++nextId, name: f.name, dataUrl: f.dataUrl };
    await dbPut("gallery", photo);
    await saveNextId();
    DATA.gallery.push(photo);
  }
  pendingGalleryFiles = [];
  document.getElementById("gFileInput").value = "";
  document.getElementById("uploadChosen").textContent = "";
  document.getElementById("imgPreviewStrip").innerHTML = "";
  renderAdminGallery(); renderGallery();
  showToast("All photos saved! ✓", "success");
}

function renderGallery() {
  const grid = document.getElementById("galleryGrid");
  const empty = document.getElementById("galleryEmpty");
  if (!grid) return;
  grid.innerHTML = "";
  if (!DATA.gallery.length) { if (empty) empty.style.display = ""; return; }
  if (empty) empty.style.display = "none";
  DATA.gallery.forEach((photo, idx) => {
    const cell = document.createElement("div");
    cell.className = "gallery-cell";
    const img = document.createElement("img");
    img.src = photo.dataUrl; img.alt = photo.name || ""; img.loading = "lazy";
    cell.appendChild(img);
    cell.onclick = () => openLightbox(DATA.gallery, idx);
    grid.appendChild(cell);
  });
}

function renderAdminGallery() {
  const wrap = document.getElementById("adminGalleryThumbs");
  if (!wrap) return;
  wrap.innerHTML = "";
  if (!DATA.gallery.length) { wrap.innerHTML = '<p style="color:var(--muted);font-size:13px;">No photos yet.</p>'; return; }
  DATA.gallery.forEach(p => {
    const w = document.createElement("div");
    w.className = "thumb-wrap";
    w.innerHTML = '<img src="' + p.dataUrl + '" alt=""/><button class="del-thumb" onclick="deleteGalleryPhoto(' + p.id + ')">&#x2715;</button>';
    wrap.appendChild(w);
  });
}

async function deleteGalleryPhoto(id) {
  await dbDelete("gallery", id);
  DATA.gallery = DATA.gallery.filter(p => p.id !== id);
  renderAdminGallery(); renderGallery();
  showToast("Photo removed.", "error");
}

/* ── LIGHTBOX ── */
let lbPhotos = [], lbIndex = 0;
function openLightbox(photos, index) {
  lbPhotos = photos; lbIndex = index; showLbPhoto();
  document.getElementById("lightbox").classList.add("open");
  document.body.style.overflow = "hidden";
}
function showLbPhoto() {
  const p = lbPhotos[lbIndex];
  document.getElementById("lbImg").src = p.dataUrl || p.url || p.src || "";
}
function closeLightbox() {
  document.getElementById("lightbox").classList.remove("open");
  document.body.style.overflow = "";
}
function lbNav(dir, e) {
  if (e) e.stopPropagation();
  lbIndex = (lbIndex + dir + lbPhotos.length) % lbPhotos.length;
  showLbPhoto();
}
document.addEventListener("keydown", e => {
  if (!document.getElementById("lightbox").classList.contains("open")) return;
  if (e.key === "ArrowLeft")  lbNav(-1);
  if (e.key === "ArrowRight") lbNav(1);
  if (e.key === "Escape")     closeLightbox();
});
const lb = document.getElementById("lightbox");
if (lb) lb.addEventListener("click", function(e) { if (e.target === this) closeLightbox(); });

/* ══════════════════════
   UNFINISHED
══════════════════════ */
function renderUnfinished() {
  const grid = document.getElementById("unfinishedGrid");
  if (!grid) return;
  grid.innerHTML = "";
  if (!DATA.unfinished.length) { grid.innerHTML = '<p style="color:var(--muted);font-size:14px;">No unfinished projects yet.</p>'; return; }
  DATA.unfinished.forEach(u => {
    const div = document.createElement("div");
    div.className = "unfinished-card";
    div.innerHTML =
      '<div class="project-meta">' + (u.category || "Coming Soon") + '</div>' +
      '<h3>' + u.title + '</h3><p style="margin-bottom:16px;">' + (u.desc || "") + '</p>' +
      '<div class="progress-label"><span>Build Progress</span><span style="color:var(--accent);font-weight:700;">' + u.progress + '%</span></div>' +
      '<div class="bar">' + (u.progress < 100 ? '<div class="progress-stripe" style="width:' + u.progress + '%"></div>' : '<div class="fill" style="width:100%"></div>') + '</div>';
    grid.appendChild(div);
  });
}

function renderAdminUnfinished() {
  const list = document.getElementById("adminUnfinishedList");
  if (!list) return;
  list.innerHTML = "";
  if (!DATA.unfinished.length) { list.innerHTML = '<p style="color:var(--muted);font-size:13px;">No unfinished projects yet.</p>'; return; }
  DATA.unfinished.forEach(u => {
    const div = document.createElement("div");
    div.className = "admin-list-item";
    div.style.flexDirection = "column"; div.style.alignItems = "stretch";
    div.innerHTML =
      '<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">' +
        '<div style="width:40px;height:40px;border-radius:6px;background:var(--surface2);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;">🔧</div>' +
        '<div style="flex:1;min-width:0;"><div style="font-weight:600;font-size:13px;color:var(--text);margin-bottom:2px;">' + u.title + '</div>' +
        '<div style="font-size:11px;color:var(--muted);">' + u.category + '</div></div>' +
        '<button class="admin-btn danger" onclick="deleteUnfinished(' + u.id + ')">Delete</button></div>' +
      '<label class="admin-label">Progress: <span id="prog-lbl-' + u.id + '" style="color:var(--accent);">' + u.progress + '%</span></label>' +
      '<div class="range-row"><input type="range" min="0" max="100" value="' + u.progress + '" oninput="updateProgress(' + u.id + ', this.value)"/></div>';
    list.appendChild(div);
  });
}

async function updateProgress(id, val) {
  const lbl = document.getElementById("prog-lbl-" + id);
  if (lbl) lbl.textContent = val + "%";
  const u = DATA.unfinished.find(u => u.id === id);
  if (u) { u.progress = parseInt(val); await dbPut("unfinished", u); }
}

async function addUnfinished() {
  const title = document.getElementById("uTitle").value.trim();
  if (!title) { showToast("Title is required.", "error"); return; }
  const u = {
    id: ++nextId, title,
    category: document.getElementById("uCategory").value.trim() || "In Progress",
    desc:     document.getElementById("uDesc").value.trim(),
    progress: parseInt(document.getElementById("uProgress").value)
  };
  await dbPut("unfinished", u);
  await saveNextId();
  DATA.unfinished.push(u);
  ["uTitle","uCategory","uDesc"].forEach(id => document.getElementById(id).value = "");
  document.getElementById("uProgress").value = 40;
  document.getElementById("uProgressVal").textContent = "40%";
  renderAdminUnfinished();
  showToast("Added! ✓", "success");
}

async function deleteUnfinished(id) {
  await dbDelete("unfinished", id);
  DATA.unfinished = DATA.unfinished.filter(u => u.id !== id);
  renderAdminUnfinished();
  showToast("Removed.", "error");
}

/* ══════════════════════
   SKILLS
══════════════════════ */
function renderSkills() {
  const grid = document.getElementById("skillsGrid");
  if (!grid) return;
  grid.innerHTML = "";
  if (!DATA.skills || !DATA.skills.length) { grid.innerHTML = '<p style="color:var(--muted);font-size:14px;">No skills added yet.</p>'; return; }
  DATA.skills.forEach(s => {
    const card = document.createElement("div");
    card.className = "skill-card";
    card.innerHTML = '<label>' + s.name + ' <span>' + s.percent + '%</span></label><div class="bar"><div class="fill" style="width:' + s.percent + '%"></div></div>';
    grid.appendChild(card);
  });
}

function renderAdminSkills() {
  const list = document.getElementById("adminSkillsList");
  if (!list) return;
  list.innerHTML = "";
  if (!DATA.skills || !DATA.skills.length) { list.innerHTML = '<p style="color:var(--muted);font-size:13px;">No skills yet.</p>'; return; }
  DATA.skills.forEach(s => {
    const div = document.createElement("div");
    div.className = "admin-list-item";
    div.style.flexDirection = "column"; div.style.alignItems = "stretch";
    div.innerHTML =
      '<div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">' +
        '<div style="width:40px;height:40px;border-radius:6px;background:var(--surface2);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;">⚡</div>' +
        '<div style="flex:1;min-width:0;"><div style="font-weight:600;font-size:13px;color:var(--text);">' + s.name + '</div>' +
        '<div style="font-size:11px;color:var(--muted);">' + s.percent + '%</div></div>' +
        '<button class="admin-btn danger" onclick="deleteSkill(' + s.id + ')">Delete</button></div>' +
      '<label class="admin-label">Percentage: <span id="skill-lbl-' + s.id + '" style="color:var(--accent);">' + s.percent + '%</span></label>' +
      '<div class="range-row"><input type="range" min="0" max="100" value="' + s.percent + '" oninput="updateSkill(' + s.id + ', this.value)"/></div>';
    list.appendChild(div);
  });
}

async function addSkill() {
  const name = document.getElementById("skillName").value.trim();
  if (!name) { showToast("Skill name is required.", "error"); return; }
  const s = { id: ++nextId, name, percent: parseInt(document.getElementById("skillPercent").value) };
  await dbPut("skills", s);
  await saveNextId();
  DATA.skills.push(s);
  document.getElementById("skillName").value = "";
  document.getElementById("skillPercent").value = 50;
  document.getElementById("skillPercentVal").textContent = "50%";
  renderAdminSkills(); renderSkills();
  showToast("Skill added! ✓", "success");
}

async function updateSkill(id, val) {
  const lbl = document.getElementById("skill-lbl-" + id);
  if (lbl) lbl.textContent = val + "%";
  const s = DATA.skills.find(s => s.id === id);
  if (s) { s.percent = parseInt(val); await dbPut("skills", s); renderSkills(); }
}

async function deleteSkill(id) {
  await dbDelete("skills", id);
  DATA.skills = DATA.skills.filter(s => s.id !== id);
  renderAdminSkills(); renderSkills();
  showToast("Skill removed.", "error");
}

/* ── UTILITIES ── */
function formatBytes(bytes) {
  if (!bytes) return "";
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / 1048576).toFixed(1) + " MB";
}
function capitalize(str) { return str.replace(/\b\w/g, c => c.toUpperCase()); }

/* ── START ── */
initDB().catch(err => {
  console.error("DB init failed:", err);
  showToast("Could not open storage. Try a different browser.", "error");
});